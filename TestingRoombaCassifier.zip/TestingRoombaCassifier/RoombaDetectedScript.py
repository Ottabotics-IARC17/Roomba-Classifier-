import numpy as np
import cv2 
import sys

RoombaDetected = False 

def main(arg):
	 RoombaDetected = arg 
	 print("Roomba Detected = " + str(RoombaDetected))

if __name__ == "__main__" : 
	main(sys.argv[1])












